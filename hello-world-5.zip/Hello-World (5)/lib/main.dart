import 'package:flutter/material.dart';
void main() => runApp(MyApp());
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext c) {
    return MaterialApp(debugShowCheckedModeBanner:false, home:ContactBook());
  }
}
class Contact{String name;String phone;Contact({required this.name,required this.phone});}
class ContactBook extends StatefulWidget{
  @override _ContactBookState createState()=>_ContactBookState();
}
class _ContactBookState extends State<ContactBook>{
  List<Contact> contacts=[]; List<Contact> filtered=[];
  var nameC=TextEditingController(); var phoneC=TextEditingController(); var searchC=TextEditingController();
  @override void initState(){super.initState(); filtered=contacts; searchC.addListener((){
    setState((){
      filtered=contacts.where((x)=>x.name.toLowerCase().contains(searchC.text.toLowerCase())||x.phone.contains(searchC.text)).toList();
    });
  });}
  void add(){
    if(nameC.text.isNotEmpty && phoneC.text.isNotEmpty){
      setState((){
        contacts.add(Contact(name:nameC.text,phone:phoneC.text));
        filtered=contacts; nameC.clear(); phoneC.clear();
      });
      Navigator.pop(context);
    }
  }
  void showAdd(){
    showDialog(context:context,builder:(_)=>AlertDialog(
      title:Text("Add Contact"),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:nameC,decoration:InputDecoration(labelText:"Name",border:OutlineInputBorder())),
        SizedBox(height:10),
        TextField(controller:phoneC,decoration:InputDecoration(labelText:"Phone",border:OutlineInputBorder()),keyboardType:TextInputType.phone),
      ]),
      actions:[TextButton(onPressed:()=>Navigator.pop(context),child:Text("Cancel")), ElevatedButton(onPressed:add,child:Text("Save"))],
    ));
  }
  @override Widget build(BuildContext context){
    return Scaffold(
      appBar:AppBar(title:Text("Contact Book"),centerTitle:true,backgroundColor:Colors.blue,foregroundColor:Colors.white),
      body:Column(children:[
        Padding(padding:EdgeInsets.all(12),child:TextField(controller:searchC,decoration:InputDecoration(labelText:"Search...",prefixIcon:Icon(Icons.search),border:OutlineInputBorder(borderRadius:BorderRadius.circular(12))))),
        Expanded(child:filtered.isEmpty?Center(child:Text(contacts.isEmpty?"No contacts yet":"No result")):ListView.builder(itemCount:filtered.length,itemBuilder:(c,i){
          return Card(margin:EdgeInsets.symmetric(horizontal:12,vertical:5),child:ListTile(
            leading:CircleAvatar(child:Text(filtered[i].name[0].toUpperCase())),
            title:Text(filtered[i].name,style:TextStyle(fontWeight:FontWeight.bold)),
            subtitle:Text(filtered[i].phone),
            trailing:IconButton(icon:Icon(Icons.delete,color:Colors.red),onPressed:(){
              setState((){
                contacts.remove(filtered[i]); filtered=List.from(contacts);
              });
            }),
          ));
        })),
      ]),
      floatingActionButton:FloatingActionButton(onPressed:showAdd,child:Icon(Icons.add)),
    );
  }
}